import { useState } from 'react';
import { Account, ColumnWidths } from '../App';
import { ChevronRight, ChevronDown, Plus, Trash2, Edit } from 'lucide-react';
import { Button } from './ui/button';

interface AccountNodeProps {
  account: Account;
  level: number;
  onAddChild: (parent: Account) => void;
  onEdit: (account: Account) => void;
  onDelete: (accountId: string) => void;
  columnWidths: ColumnWidths;
}

export function AccountNode({ account, level, onAddChild, onEdit, onDelete, columnWidths }: AccountNodeProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const hasChildren = account.children && account.children.length > 0;

  const getValidation = () => {
    const indicator = account.isIncome ? ' (+) ' : ' (-) ';
    return `${account.code}.${indicator}${account.name}`;
  };

  const totalWidth = Object.values(columnWidths).reduce((sum, width) => sum + width, 0);
  const paddingLeft = 1.5 + level * 2;

  return (
    <div>
      <div
        className="flex hover:bg-slate-50 transition-colors border-b px-6 py-3"
        style={{ minWidth: `${totalWidth}px` }}
      >
        <div 
          className="flex items-center"
          style={{ 
            width: `${columnWidths.code}px`, 
            minWidth: `${columnWidths.code}px`,
            paddingLeft: `${paddingLeft}rem`
          }}
        >
          <span className="text-slate-600">{account.code}.</span>
        </div>
        
        <div 
          className="flex items-center gap-2"
          style={{ width: `${columnWidths.name}px`, minWidth: `${columnWidths.name}px` }}
        >
          {hasChildren ? (
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1 hover:bg-slate-200 rounded transition-colors flex-shrink-0"
            >
              {isExpanded ? (
                <ChevronDown className="h-4 w-4 text-slate-600" />
              ) : (
                <ChevronRight className="h-4 w-4 text-slate-600" />
              )}
            </button>
          ) : (
            <div className="w-6 flex-shrink-0" />
          )}
          <span className="text-slate-900 truncate">{account.name}</span>
        </div>
        
        <div 
          className="flex items-center justify-center"
          style={{ width: `${columnWidths.isIncome}px`, minWidth: `${columnWidths.isIncome}px` }}
        >
          <span className={`px-2 py-1 rounded text-xs ${account.isIncome ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
            {account.isIncome ? 'True' : 'False'}
          </span>
        </div>

        <div 
          className="flex items-center"
          style={{ width: `${columnWidths.validation}px`, minWidth: `${columnWidths.validation}px` }}
        >
          <span className="text-slate-700 truncate">{getValidation()}</span>
        </div>
        
        <div 
          className="flex items-center"
          style={{ width: `${columnWidths.description}px`, minWidth: `${columnWidths.description}px` }}
        >
          <span className="text-slate-600 text-sm truncate">{account.description}</span>
        </div>

        <div 
          className="flex items-center justify-center"
          style={{ width: `${columnWidths.pnl}px`, minWidth: `${columnWidths.pnl}px` }}
        >
          <span className="px-2 py-1 rounded text-xs bg-slate-100 text-slate-800">
            {account.pnl ? 'True' : 'False'}
          </span>
        </div>

        <div 
          className="flex items-center justify-center"
          style={{ width: `${columnWidths.cf}px`, minWidth: `${columnWidths.cf}px` }}
        >
          <span className="px-2 py-1 rounded text-xs bg-slate-100 text-slate-800">
            {account.cf ? 'True' : 'False'}
          </span>
        </div>
        
        <div 
          className="flex items-center justify-end gap-1"
          style={{ width: `${columnWidths.actions}px`, minWidth: `${columnWidths.actions}px` }}
        >
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onAddChild(account)}
            className="h-8 px-2"
          >
            <Plus className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onEdit(account)}
            className="h-8 px-2"
          >
            <Edit className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onDelete(account.id)}
            className="h-8 px-2 text-red-600 hover:text-red-700 hover:bg-red-50"
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {hasChildren && isExpanded && (
        <div>
          {account.children!.map((child) => (
            <AccountNode
              key={child.id}
              account={child}
              level={level + 1}
              onAddChild={onAddChild}
              onEdit={onEdit}
              onDelete={onDelete}
              columnWidths={columnWidths}
            />
          ))}
        </div>
      )}
    </div>
  );
}
