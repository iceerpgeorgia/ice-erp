import { useState, useRef } from 'react';
import { Account, ColumnWidths } from '../App';
import { AccountNode } from './AccountNode';
import { GripVertical } from 'lucide-react';

interface ChartOfAccountsProps {
  accounts: Account[];
  onAddChild: (parent: Account) => void;
  onEdit: (account: Account) => void;
  onDelete: (accountId: string) => void;
  columnWidths: ColumnWidths;
  onColumnWidthChange: (widths: ColumnWidths) => void;
}

export function ChartOfAccounts({ 
  accounts, 
  onAddChild, 
  onEdit, 
  onDelete,
  columnWidths,
  onColumnWidthChange
}: ChartOfAccountsProps) {
  const [resizing, setResizing] = useState<keyof ColumnWidths | null>(null);
  const startXRef = useRef(0);
  const startWidthRef = useRef(0);

  const handleMouseDown = (column: keyof ColumnWidths, e: React.MouseEvent) => {
    e.preventDefault();
    setResizing(column);
    startXRef.current = e.clientX;
    startWidthRef.current = columnWidths[column];

    const handleMouseMove = (e: MouseEvent) => {
      if (!resizing && column) {
        const delta = e.clientX - startXRef.current;
        const newWidth = Math.max(50, startWidthRef.current + delta);
        onColumnWidthChange({
          ...columnWidths,
          [column]: newWidth,
        });
      }
    };

    const handleMouseUp = () => {
      setResizing(null);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const totalWidth = Object.values(columnWidths).reduce((sum, width) => sum + width, 0);

  return (
    <div className="divide-y">
      <div 
        className="flex bg-slate-50 border-b px-6 py-3 select-none"
        style={{ minWidth: `${totalWidth}px` }}
      >
        <div 
          className="flex items-center text-slate-600 relative group"
          style={{ width: `${columnWidths.code}px`, minWidth: `${columnWidths.code}px` }}
        >
          <span>Code</span>
          <div
            className="absolute right-0 top-0 h-full w-1 cursor-col-resize hover:bg-blue-500 flex items-center justify-center group-hover:opacity-100 opacity-0 transition-opacity"
            onMouseDown={(e) => handleMouseDown('code', e)}
          >
            <GripVertical className="h-4 w-4 text-slate-400" />
          </div>
        </div>

        <div 
          className="flex items-center text-slate-600 relative group"
          style={{ width: `${columnWidths.name}px`, minWidth: `${columnWidths.name}px` }}
        >
          <span>Name</span>
          <div
            className="absolute right-0 top-0 h-full w-1 cursor-col-resize hover:bg-blue-500 flex items-center justify-center group-hover:opacity-100 opacity-0 transition-opacity"
            onMouseDown={(e) => handleMouseDown('name', e)}
          >
            <GripVertical className="h-4 w-4 text-slate-400" />
          </div>
        </div>

        <div 
          className="flex items-center justify-center text-slate-600 relative group"
          style={{ width: `${columnWidths.isIncome}px`, minWidth: `${columnWidths.isIncome}px` }}
        >
          <span>Is Income</span>
          <div
            className="absolute right-0 top-0 h-full w-1 cursor-col-resize hover:bg-blue-500 flex items-center justify-center group-hover:opacity-100 opacity-0 transition-opacity"
            onMouseDown={(e) => handleMouseDown('isIncome', e)}
          >
            <GripVertical className="h-4 w-4 text-slate-400" />
          </div>
        </div>

        <div 
          className="flex items-center text-slate-600 relative group"
          style={{ width: `${columnWidths.validation}px`, minWidth: `${columnWidths.validation}px` }}
        >
          <span>Validation</span>
          <div
            className="absolute right-0 top-0 h-full w-1 cursor-col-resize hover:bg-blue-500 flex items-center justify-center group-hover:opacity-100 opacity-0 transition-opacity"
            onMouseDown={(e) => handleMouseDown('validation', e)}
          >
            <GripVertical className="h-4 w-4 text-slate-400" />
          </div>
        </div>

        <div 
          className="flex items-center text-slate-600 relative group"
          style={{ width: `${columnWidths.description}px`, minWidth: `${columnWidths.description}px` }}
        >
          <span>Description</span>
          <div
            className="absolute right-0 top-0 h-full w-1 cursor-col-resize hover:bg-blue-500 flex items-center justify-center group-hover:opacity-100 opacity-0 transition-opacity"
            onMouseDown={(e) => handleMouseDown('description', e)}
          >
            <GripVertical className="h-4 w-4 text-slate-400" />
          </div>
        </div>

        <div 
          className="flex items-center justify-center text-slate-600 relative group"
          style={{ width: `${columnWidths.pnl}px`, minWidth: `${columnWidths.pnl}px` }}
        >
          <span>P&L</span>
          <div
            className="absolute right-0 top-0 h-full w-1 cursor-col-resize hover:bg-blue-500 flex items-center justify-center group-hover:opacity-100 opacity-0 transition-opacity"
            onMouseDown={(e) => handleMouseDown('pnl', e)}
          >
            <GripVertical className="h-4 w-4 text-slate-400" />
          </div>
        </div>

        <div 
          className="flex items-center justify-center text-slate-600 relative group"
          style={{ width: `${columnWidths.cf}px`, minWidth: `${columnWidths.cf}px` }}
        >
          <span>CF</span>
          <div
            className="absolute right-0 top-0 h-full w-1 cursor-col-resize hover:bg-blue-500 flex items-center justify-center group-hover:opacity-100 opacity-0 transition-opacity"
            onMouseDown={(e) => handleMouseDown('cf', e)}
          >
            <GripVertical className="h-4 w-4 text-slate-400" />
          </div>
        </div>

        <div 
          className="flex items-center justify-end text-slate-600"
          style={{ width: `${columnWidths.actions}px`, minWidth: `${columnWidths.actions}px` }}
        >
          <span>Actions</span>
        </div>
      </div>
      
      <div>
        {accounts.map((account) => (
          <AccountNode
            key={account.id}
            account={account}
            level={0}
            onAddChild={onAddChild}
            onEdit={onEdit}
            onDelete={onDelete}
            columnWidths={columnWidths}
          />
        ))}
      </div>
    </div>
  );
}
