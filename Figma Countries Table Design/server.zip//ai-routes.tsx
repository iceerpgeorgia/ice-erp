import { Hono } from "npm:hono";

const aiApp = new Hono();

// Helper function to call OpenAI API
async function callOpenAI(messages: any[], model = "gpt-4") {
  const apiKey = Deno.env.get('OPENAI_API_KEY');
  if (!apiKey) {
    throw new Error('OpenAI API key not configured');
  }

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: 0.1,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`OpenAI API error: ${error}`);
  }

  return await response.json();
}

// Auto-complete country information
aiApp.post('/make-server-b17cb9fd/ai/complete-country', async (c) => {
  try {
    const { partial_name } = await c.req.json();

    const messages = [
      {
        role: "system",
        content: `You are a country data expert. When given a partial or full country name, provide complete country information in JSON format. Always respond with valid JSON only.

Required format:
{
  "name_en": "English name",
  "name_ka": "Georgian name (if known, otherwise null)",
  "iso2": "2-letter ISO code",
  "iso3": "3-letter ISO code", 
  "un_code": numeric_un_code_or_null,
  "country": "Official country name",
  "confidence": 0.95
}

For Georgian translations, use proper Georgian script. If you're unsure about Georgian translation, set name_ka to null.`
      },
      {
        role: "user",
        content: `Complete country information for: "${partial_name}"`
      }
    ];

    const response = await callOpenAI(messages);
    const aiResponse = response.choices[0].message.content;

    // Parse JSON response
    const countryData = JSON.parse(aiResponse);

    return c.json({ success: true, data: countryData });
  } catch (error) {
    console.error('AI completion error:', error);
    return c.json({ 
      success: false, 
      error: `Failed to complete country information: ${error.message}` 
    }, 500);
  }
});

// Validate country data
aiApp.post('/make-server-b17cb9fd/ai/validate-country', async (c) => {
  try {
    const countryData = await c.req.json();

    const messages = [
      {
        role: "system",
        content: `You are a country data validator. Analyze the provided country data and identify any errors, inconsistencies, or missing information. Respond with JSON only.

Required format:
{
  "is_valid": boolean,
  "errors": ["list", "of", "errors"],
  "warnings": ["list", "of", "warnings"],
  "suggestions": {
    "field_name": "suggested_value"
  },
  "confidence": 0.95
}`
      },
      {
        role: "user",
        content: `Validate this country data: ${JSON.stringify(countryData)}`
      }
    ];

    const response = await callOpenAI(messages);
    const validation = JSON.parse(response.choices[0].message.content);

    return c.json({ success: true, validation });
  } catch (error) {
    console.error('AI validation error:', error);
    return c.json({ 
      success: false, 
      error: `Failed to validate country data: ${error.message}` 
    }, 500);
  }
});

// Generate multiple countries from description
aiApp.post('/make-server-b17cb9fd/ai/generate-countries', async (c) => {
  try {
    const { description, count = 5 } = await c.req.json();

    const messages = [
      {
        role: "system",
        content: `You are a country database generator. Based on user descriptions, generate country data. Always respond with valid JSON only.

Required format:
{
  "countries": [
    {
      "name_en": "English name",
      "name_ka": "Georgian name (if known, otherwise null)",
      "iso2": "2-letter ISO code",
      "iso3": "3-letter ISO code",
      "un_code": numeric_un_code_or_null,
      "country": "Official country name",
      "is_active": true
    }
  ]
}

Generate accurate, real country data only. Do not create fictional countries.`
      },
      {
        role: "user",
        content: `Generate ${count} countries based on: "${description}"`
      }
    ];

    const response = await callOpenAI(messages);
    const generated = JSON.parse(response.choices[0].message.content);

    return c.json({ success: true, data: generated });
  } catch (error) {
    console.error('AI generation error:', error);
    return c.json({ 
      success: false, 
      error: `Failed to generate countries: ${error.message}` 
    }, 500);
  }
});

// Smart search with natural language
aiApp.post('/make-server-b17cb9fd/ai/smart-search', async (c) => {
  try {
    const { query, countries } = await c.req.json();

    const messages = [
      {
        role: "system",
        content: `You are a smart search assistant for country data. Analyze the user's natural language query and return relevant country IDs from the provided dataset. Consider synonyms, alternative names, geographical regions, and related concepts.

Required format:
{
  "matched_ids": ["id1", "id2"],
  "reasoning": "Brief explanation of matches",
  "confidence": 0.95
}

Be flexible with matching - consider partial matches, historical names, regional groupings, etc.`
      },
      {
        role: "user",
        content: `Search query: "${query}"\n\nAvailable countries: ${JSON.stringify(countries)}`
      }
    ];

    const response = await callOpenAI(messages);
    const searchResult = JSON.parse(response.choices[0].message.content);

    return c.json({ success: true, data: searchResult });
  } catch (error) {
    console.error('AI search error:', error);
    return c.json({ 
      success: false, 
      error: `Failed to perform smart search: ${error.message}` 
    }, 500);
  }
});

// Translate country names to Georgian
aiApp.post('/make-server-b17cb9fd/ai/translate-georgian', async (c) => {
  try {
    const { country_names } = await c.req.json();

    const messages = [
      {
        role: "system",
        content: `You are a Georgian translation expert. Translate country names to Georgian script. Respond with JSON only.

Required format:
{
  "translations": {
    "English Name": "ქართული თარგმანი",
    "Another Name": "სხვა თარგმანი"
  }
}

Use proper Georgian script and official country name translations used in Georgia.`
      },
      {
        role: "user",
        content: `Translate these country names to Georgian: ${JSON.stringify(country_names)}`
      }
    ];

    const response = await callOpenAI(messages);
    const translations = JSON.parse(response.choices[0].message.content);

    return c.json({ success: true, data: translations });
  } catch (error) {
    console.error('AI translation error:', error);
    return c.json({ 
      success: false, 
      error: `Failed to translate to Georgian: ${error.message}` 
    }, 500);
  }
});

export default aiApp;