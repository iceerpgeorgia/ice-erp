import React, { useState, useMemo } from 'react';
import { Search, Plus, Edit2, Check, X, Filter } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Checkbox } from './ui/checkbox';

// Sample data - replace with your backend data
const initialCountries = [
  {
    id: 1,
    name_en: 'Georgia',
    name_ka: 'საქართველო',
    iso2: 'GE',
    iso3: 'GEO',
    un_code: 268,
    active: true
  },
  {
    id: 2,
    name_en: 'United States',
    name_ka: 'შეერთებული შტატები',
    iso2: 'US',
    iso3: 'USA',
    un_code: 840,
    active: true
  },
  {
    id: 3,
    name_en: 'United Kingdom',
    name_ka: 'გაერთიანებული სამეფო',
    iso2: 'GB',
    iso3: 'GBR',
    un_code: 826,
    active: false
  }
];

type Country = {
  id: number;
  name_en: string;
  name_ka: string;
  iso2: string;
  iso3: string;
  un_code: number;
  active: boolean;
};

export function CountriesTable() {
  const [countries, setCountries] = useState<Country[]>(initialCountries);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<keyof Country | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [filterColumn, setFilterColumn] = useState<keyof Country | null>(null);
  const [columnFilters, setColumnFilters] = useState<Record<string, string[]>>({});

  // Form state
  const [formData, setFormData] = useState({
    name_en: '',
    name_ka: '',
    iso2: '',
    iso3: '',
    un_code: '',
    active: true
  });

  // Filter and search logic
  const filteredCountries = useMemo(() => {
    let filtered = countries;

    // Apply search
    if (searchTerm) {
      filtered = filtered.filter(country =>
        country.name_en.toLowerCase().includes(searchTerm.toLowerCase()) ||
        country.name_ka.toLowerCase().includes(searchTerm.toLowerCase()) ||
        country.iso2.toLowerCase().includes(searchTerm.toLowerCase()) ||
        country.iso3.toLowerCase().includes(searchTerm.toLowerCase()) ||
        country.un_code.toString().includes(searchTerm)
      );
    }

    // Apply column filters
    Object.entries(columnFilters).forEach(([column, values]) => {
      if (values.length > 0) {
        filtered = filtered.filter(country => {
          const cellValue = String(country[column as keyof Country]);
          return values.includes(cellValue);
        });
      }
    });

    return filtered;
  }, [countries, searchTerm, columnFilters]);

  // Sort logic
  const sortedCountries = useMemo(() => {
    if (!sortField) return filteredCountries;

    return [...filteredCountries].sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      
      if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredCountries, sortField, sortDirection]);

  const handleSort = (field: keyof Country) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleSave = () => {
    if (editingId) {
      // Update existing
      setCountries(countries.map(country =>
        country.id === editingId
          ? { ...country, ...formData, un_code: parseInt(formData.un_code) }
          : country
      ));
      setEditingId(null);
    } else {
      // Add new
      const newCountry = {
        id: Math.max(...countries.map(c => c.id)) + 1,
        ...formData,
        un_code: parseInt(formData.un_code)
      };
      setCountries([...countries, newCountry]);
      setIsAddDialogOpen(false);
    }
    
    setFormData({
      name_en: '',
      name_ka: '',
      iso2: '',
      iso3: '',
      un_code: '',
      active: true
    });
  };

  const startEdit = (country: Country) => {
    setEditingId(country.id);
    setFormData({
      name_en: country.name_en,
      name_ka: country.name_ka,
      iso2: country.iso2,
      iso3: country.iso3,
      un_code: country.un_code.toString(),
      active: country.active
    });
  };

  const cancelEdit = () => {
    setEditingId(null);
    setFormData({
      name_en: '',
      name_ka: '',
      iso2: '',
      iso3: '',
      un_code: '',
      active: true
    });
  };

  // Get unique values for column filters
  const getUniqueValues = (column: keyof Country) => {
    return [...new Set(countries.map(country => String(country[column])))];
  };

  const ColumnFilter = ({ column, title }: { column: keyof Country; title: string }) => {
    const uniqueValues = getUniqueValues(column);
    const selectedValues = columnFilters[column] || [];

    return (
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="ghost" size="sm" className="h-6 px-1">
            <Filter className="h-3 w-3" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-48" align="start">
          <div className="space-y-2">
            <div className="font-medium text-sm">{title}</div>
            <div className="space-y-1 max-h-48 overflow-auto">
              {uniqueValues.map(value => (
                <div key={value} className="flex items-center space-x-2">
                  <Checkbox
                    id={`${column}-${value}`}
                    checked={selectedValues.includes(value)}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        setColumnFilters({
                          ...columnFilters,
                          [column]: [...selectedValues, value]
                        });
                      } else {
                        setColumnFilters({
                          ...columnFilters,
                          [column]: selectedValues.filter(v => v !== value)
                        });
                      }
                    }}
                  />
                  <Label htmlFor={`${column}-${value}`} className="text-sm">
                    {value}
                  </Label>
                </div>
              ))}
            </div>
            {selectedValues.length > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setColumnFilters({
                  ...columnFilters,
                  [column]: []
                })}
                className="w-full"
              >
                Clear
              </Button>
            )}
          </div>
        </PopoverContent>
      </Popover>
    );
  };

  return (
    <div className="p-6 space-y-4">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Countries</h1>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Country
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Country</DialogTitle>
              <DialogDescription>
                Enter the details for the new country.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name_en" className="text-right">
                  English Name
                </Label>
                <Input
                  id="name_en"
                  value={formData.name_en}
                  onChange={(e) => setFormData({...formData, name_en: e.target.value})}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name_ka" className="text-right">
                  Georgian Name
                </Label>
                <Input
                  id="name_ka"
                  value={formData.name_ka}
                  onChange={(e) => setFormData({...formData, name_ka: e.target.value})}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="iso2" className="text-right">
                  ISO2
                </Label>
                <Input
                  id="iso2"
                  value={formData.iso2}
                  onChange={(e) => setFormData({...formData, iso2: e.target.value})}
                  className="col-span-3"
                  maxLength={2}
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="iso3" className="text-right">
                  ISO3
                </Label>
                <Input
                  id="iso3"
                  value={formData.iso3}
                  onChange={(e) => setFormData({...formData, iso3: e.target.value})}
                  className="col-span-3"
                  maxLength={3}
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="un_code" className="text-right">
                  UN Code
                </Label>
                <Input
                  id="un_code"
                  type="number"
                  value={formData.un_code}
                  onChange={(e) => setFormData({...formData, un_code: e.target.value})}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="active" className="text-right">
                  Active
                </Label>
                <Switch
                  id="active"
                  checked={formData.active}
                  onCheckedChange={(checked) => setFormData({...formData, active: checked})}
                />
              </div>
            </div>
            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleSave}>Save</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <div className="flex items-center space-x-2">
        <Search className="h-4 w-4 text-gray-400" />
        <Input
          placeholder="Search countries..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-sm"
        />
      </div>

      {/* Table */}
      <div className="border rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="px-4 py-3 text-left">
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => handleSort('name_en')}
                      className="font-medium hover:text-blue-600"
                    >
                      English Name
                    </button>
                    <ColumnFilter column="name_en" title="English Name" />
                  </div>
                </th>
                <th className="px-4 py-3 text-left hidden md:table-cell">
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => handleSort('name_ka')}
                      className="font-medium hover:text-blue-600"
                    >
                      Georgian Name
                    </button>
                    <ColumnFilter column="name_ka" title="Georgian Name" />
                  </div>
                </th>
                <th className="px-4 py-3 text-left">
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => handleSort('iso2')}
                      className="font-medium hover:text-blue-600"
                    >
                      ISO2
                    </button>
                    <ColumnFilter column="iso2" title="ISO2" />
                  </div>
                </th>
                <th className="px-4 py-3 text-left hidden lg:table-cell">
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => handleSort('iso3')}
                      className="font-medium hover:text-blue-600"
                    >
                      ISO3
                    </button>
                    <ColumnFilter column="iso3" title="ISO3" />
                  </div>
                </th>
                <th className="px-4 py-3 text-left hidden lg:table-cell">
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => handleSort('un_code')}
                      className="font-medium hover:text-blue-600"
                    >
                      UN Code
                    </button>
                    <ColumnFilter column="un_code" title="UN Code" />
                  </div>
                </th>
                <th className="px-4 py-3 text-left">
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => handleSort('active')}
                      className="font-medium hover:text-blue-600"
                    >
                      Status
                    </button>
                    <ColumnFilter column="active" title="Status" />
                  </div>
                </th>
                <th className="px-4 py-3 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {sortedCountries.map((country) => (
                <tr key={country.id} className="border-b hover:bg-gray-50">
                  <td className="px-4 py-3">
                    {editingId === country.id ? (
                      <Input
                        value={formData.name_en}
                        onChange={(e) => setFormData({...formData, name_en: e.target.value})}
                        className="w-full"
                      />
                    ) : (
                      country.name_en
                    )}
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    {editingId === country.id ? (
                      <Input
                        value={formData.name_ka}
                        onChange={(e) => setFormData({...formData, name_ka: e.target.value})}
                        className="w-full"
                      />
                    ) : (
                      country.name_ka
                    )}
                  </td>
                  <td className="px-4 py-3">
                    {editingId === country.id ? (
                      <Input
                        value={formData.iso2}
                        onChange={(e) => setFormData({...formData, iso2: e.target.value})}
                        className="w-full"
                        maxLength={2}
                      />
                    ) : (
                      country.iso2
                    )}
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell">
                    {editingId === country.id ? (
                      <Input
                        value={formData.iso3}
                        onChange={(e) => setFormData({...formData, iso3: e.target.value})}
                        className="w-full"
                        maxLength={3}
                      />
                    ) : (
                      country.iso3
                    )}
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell">
                    {editingId === country.id ? (
                      <Input
                        type="number"
                        value={formData.un_code}
                        onChange={(e) => setFormData({...formData, un_code: e.target.value})}
                        className="w-full"
                      />
                    ) : (
                      country.un_code
                    )}
                  </td>
                  <td className="px-4 py-3">
                    {editingId === country.id ? (
                      <Switch
                        checked={formData.active}
                        onCheckedChange={(checked) => setFormData({...formData, active: checked})}
                      />
                    ) : (
                      <Badge variant={country.active ? "default" : "secondary"}>
                        {country.active ? "Active" : "Inactive"}
                      </Badge>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center space-x-2">
                      {editingId === country.id ? (
                        <>
                          <Button size="sm" onClick={handleSave}>
                            <Check className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline" onClick={cancelEdit}>
                            <X className="h-4 w-4" />
                          </Button>
                        </>
                      ) : (
                        <Button size="sm" variant="outline" onClick={() => startEdit(country)}>
                          <Edit2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {sortedCountries.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          No countries found matching your search.
        </div>
      )}
    </div>
  );
}