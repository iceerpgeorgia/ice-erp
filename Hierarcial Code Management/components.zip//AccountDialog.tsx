import { useState, useEffect } from 'react';
import { Account } from '../App';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Textarea } from './ui/textarea';

interface AccountDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (codeNumber: string, accountData: Omit<Account, 'id' | 'children' | 'code'>) => void;
  parentAccount?: Account | null;
  editingAccount?: Account | null;
}

export function AccountDialog({
  open,
  onOpenChange,
  onSubmit,
  parentAccount,
  editingAccount,
}: AccountDialogProps) {
  const [codeNumber, setCodeNumber] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    isIncome: false,
    pnl: false,
    cf: false,
    type: 'Asset' as Account['type'],
  });

  useEffect(() => {
    if (editingAccount) {
      setFormData({
        name: editingAccount.name,
        description: editingAccount.description,
        isIncome: editingAccount.isIncome,
        pnl: editingAccount.pnl,
        cf: editingAccount.cf,
        type: editingAccount.type,
      });
    } else {
      setFormData({
        name: '',
        description: '',
        isIncome: false,
        pnl: false,
        cf: false,
        type: 'Asset',
      });
      setCodeNumber('');
    }
  }, [editingAccount, open]);

  const getAccountLevel = (code: string): number => {
    return code.split('.').length;
  };

  const currentLevel = parentAccount ? getAccountLevel(parentAccount.code) + 1 : 1;
  const fullCodePreview = parentAccount ? `${parentAccount.code}.${codeNumber || '?'}` : codeNumber || '?';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(codeNumber, formData);
    setCodeNumber('');
    setFormData({
      name: '',
      description: '',
      isIncome: false,
      pnl: false,
      cf: false,
      type: 'Asset',
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>
            {editingAccount 
              ? `Edit Account: ${editingAccount.name}`
              : parentAccount 
                ? `Add Child Account to ${parentAccount.name}` 
                : 'Add New Root Account'}
          </DialogTitle>
          <DialogDescription>
            {editingAccount
              ? `Editing account ${editingAccount.code} - ${editingAccount.name}`
              : parentAccount
                ? `Create a level ${currentLevel} sub-account under ${parentAccount.code} - ${parentAccount.name}`
                : 'Create a new level 1 root account in the chart of accounts'}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            {!editingAccount && (
              <div className="grid gap-2">
                <Label htmlFor="code">
                  Code Number (Level {currentLevel})
                </Label>
                <div className="flex gap-2">
                  <Input
                    id="code"
                    value={codeNumber}
                    onChange={(e) => setCodeNumber(e.target.value)}
                    placeholder={currentLevel === 1 ? "e.g., 1" : "e.g., 1"}
                    required
                    className="flex-1"
                  />
                  <div className="flex items-center px-3 py-2 bg-slate-100 rounded-md border text-slate-600 min-w-[120px]">
                    <span className="text-sm">Full: {fullCodePreview}</span>
                  </div>
                </div>
                <p className="text-sm text-slate-500">
                  Enter a number for this level. Maximum 7 levels supported.
                </p>
              </div>
            )}

            <div className="grid gap-2">
              <Label htmlFor="name">Account Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Cash"
                required
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="isIncome">Is Income</Label>
              <Switch
                id="isIncome"
                checked={formData.isIncome}
                onCheckedChange={(checked) => setFormData({ ...formData, isIncome: checked })}
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="pnl">P&L</Label>
              <Switch
                id="pnl"
                checked={formData.pnl}
                onCheckedChange={(checked) => setFormData({ ...formData, pnl: checked })}
              />
            </div>

            <div className="flex items-center justify-between">
              <Label htmlFor="cf">CF</Label>
              <Switch
                id="cf"
                checked={formData.cf}
                onCheckedChange={(checked) => setFormData({ ...formData, cf: checked })}
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Enter account description"
                rows={3}
              />
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">{editingAccount ? 'Save Changes' : 'Add Account'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
