import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  Search, 
  Plus, 
  Edit2, 
  Check, 
  X, 
  Filter, 
  ArrowUpDown, 
  ArrowUp, 
  ArrowDown,
  Settings,
  Eye,
  EyeOff
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Checkbox } from './ui/checkbox';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from './ui/table';

// Sample data matching your exact database schema
const initialCountries = [
  {
    id: 1,
    createdAt: '2025-10-01',
    updatedAt: '2025-10-02',
    ts: '2025-10-01T12:00:00',
    countryUuid: 'uuid-1234',
    nameEn: 'Georgia',
    nameKa: 'საქართველო',
    iso2: 'GE',
    iso3: 'GEO',
    unCode: 268,
    country: 'Georgia',
    isActive: true
  },
  {
    id: 2,
    createdAt: '2025-10-01',
    updatedAt: '2025-10-02',
    ts: '2025-10-01T12:30:00',
    countryUuid: 'uuid-5678',
    nameEn: 'United States',
    nameKa: 'შეერთებული შტატები',
    iso2: 'US',
    iso3: 'USA',
    unCode: 840,
    country: 'United States',
    isActive: true
  },
  {
    id: 3,
    createdAt: '2025-10-01',
    updatedAt: '2025-10-02',
    ts: '2025-10-01T13:00:00',
    countryUuid: 'uuid-9012',
    nameEn: 'United Kingdom',
    nameKa: 'გაერთიანებული სამეფო',
    iso2: 'GB',
    iso3: 'GBR',
    unCode: 826,
    country: 'United Kingdom',
    isActive: false
  },
  {
    id: 4,
    createdAt: '2025-10-01',
    updatedAt: '2025-10-02',
    ts: '2025-10-01T13:30:00',
    countryUuid: 'uuid-3456',
    nameEn: 'Germany',
    nameKa: 'გერმანია',
    iso2: 'DE',
    iso3: 'DEU',
    unCode: 276,
    country: 'Germany',
    isActive: true
  },
  {
    id: 5,
    createdAt: '2025-10-01',
    updatedAt: '2025-10-02',
    ts: '2025-10-01T14:00:00',
    countryUuid: 'uuid-7890',
    nameEn: 'France',
    nameKa: 'საფრანგეთი',
    iso2: 'FR',
    iso3: 'FRA',
    unCode: 250,
    country: 'France',
    isActive: true
  },
  {
    id: 6,
    createdAt: '2025-10-01',
    updatedAt: '2025-10-02',
    ts: '2025-10-01T14:30:00',
    countryUuid: 'uuid-2468',
    nameEn: 'Japan',
    nameKa: 'იაპონია',
    iso2: 'JP',
    iso3: 'JPN',
    unCode: 392,
    country: 'Japan',
    isActive: false
  }
];

type Country = {
  id: number;
  createdAt: string;
  updatedAt: string;
  ts: string;
  countryUuid: string;
  nameEn: string;
  nameKa: string;
  iso2: string;
  iso3: string;
  unCode: number;
  country: string;
  isActive: boolean;
};

type ColumnKey = keyof Country;

type ColumnConfig = {
  key: ColumnKey;
  label: string;
  width: number;
  visible: boolean;
  sortable: boolean;
  filterable: boolean;
  responsive?: 'sm' | 'md' | 'lg' | 'xl';
};

const defaultColumns: ColumnConfig[] = [
  { key: 'id', label: 'ID', width: 80, visible: true, sortable: true, filterable: true },
  { key: 'createdAt', label: 'Created', width: 140, visible: true, sortable: true, filterable: true, responsive: 'xl' },
  { key: 'updatedAt', label: 'Updated', width: 140, visible: true, sortable: true, filterable: true, responsive: 'xl' },
  { key: 'ts', label: 'Timestamp', width: 140, visible: true, sortable: true, filterable: true, responsive: 'lg' },
  { key: 'countryUuid', label: 'UUID', width: 200, visible: true, sortable: true, filterable: true, responsive: 'xl' },
  { key: 'nameEn', label: 'Name EN', width: 180, visible: true, sortable: true, filterable: true },
  { key: 'nameKa', label: 'Name GE', width: 200, visible: true, sortable: true, filterable: true, responsive: 'md' },
  { key: 'iso2', label: 'ISO2', width: 80, visible: true, sortable: true, filterable: true },
  { key: 'iso3', label: 'ISO3', width: 80, visible: true, sortable: true, filterable: true, responsive: 'lg' },
  { key: 'unCode', label: 'UN Code', width: 100, visible: true, sortable: true, filterable: true, responsive: 'lg' },
  { key: 'country', label: 'Country', width: 200, visible: true, sortable: true, filterable: true, responsive: 'xl' },
  { key: 'isActive', label: 'Status', width: 100, visible: true, sortable: true, filterable: true }
];

// Helper function to get responsive classes
const getResponsiveClass = (responsive?: string) => {
  switch (responsive) {
    case 'sm': return 'hidden sm:table-cell';
    case 'md': return 'hidden md:table-cell';
    case 'lg': return 'hidden lg:table-cell';
    case 'xl': return 'hidden xl:table-cell';
    default: return '';
  }
};

export function CountriesTable() {
  const [countries, setCountries] = useState<Country[]>(initialCountries);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<ColumnKey | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [editingCountry, setEditingCountry] = useState<Country | null>(null);
  const [columnFilters, setColumnFilters] = useState<Record<string, string[]>>({});
  const [columns, setColumns] = useState<ColumnConfig[]>(defaultColumns);
  const [isResizing, setIsResizing] = useState<{ column: ColumnKey; startX: number; startWidth: number } | null>(null);
  
  // Form state with validation
  const [formData, setFormData] = useState({
    nameEn: '',
    nameKa: '',
    iso2: '',
    iso3: '',
    unCode: '',
    country: '',
    isActive: true
  });
  
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Load column settings from localStorage
  useEffect(() => {
    const savedColumns = localStorage.getItem('countries-table-columns');
    if (savedColumns) {
      try {
        const parsed = JSON.parse(savedColumns);
        setColumns(parsed);
      } catch (error) {
        console.warn('Failed to parse saved column settings:', error);
      }
    }
  }, []);

  // Save column settings to localStorage
  useEffect(() => {
    localStorage.setItem('countries-table-columns', JSON.stringify(columns));
  }, [columns]);

  // Mouse events for column resizing
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isResizing) return;
      
      const diff = e.clientX - isResizing.startX;
      const newWidth = Math.max(60, isResizing.startWidth + diff);
      
      setColumns(cols => cols.map(col => 
        col.key === isResizing.column 
          ? { ...col, width: newWidth }
          : col
      ));
    };

    const handleMouseUp = () => {
      setIsResizing(null);
    };

    if (isResizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      document.body.style.cursor = 'col-resize';
      document.body.style.userSelect = 'none';
    } else {
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isResizing]);

  // Form validation
  const validateForm = () => {
    const errors: Record<string, string> = {};
    
    if (!formData.nameEn.trim()) errors.nameEn = 'English name is required';
    if (!formData.nameKa.trim()) errors.nameKa = 'Georgian name is required';
    if (!formData.iso2.trim()) errors.iso2 = 'ISO2 code is required';
    else if (formData.iso2.length !== 2) errors.iso2 = 'ISO2 must be exactly 2 characters';
    if (!formData.iso3.trim()) errors.iso3 = 'ISO3 code is required';
    else if (formData.iso3.length !== 3) errors.iso3 = 'ISO3 must be exactly 3 characters';
    if (!formData.unCode.trim()) errors.unCode = 'UN code is required';
    else if (isNaN(parseInt(formData.unCode))) errors.unCode = 'UN code must be a number';
    if (!formData.country.trim()) errors.country = 'Country field is required';
    
    // Check for duplicates
    const existingCountry = countries.find(c => 
      c.id !== editingCountry?.id && (
        c.iso2.toLowerCase() === formData.iso2.toLowerCase() ||
        c.iso3.toLowerCase() === formData.iso3.toLowerCase() ||
        c.unCode === parseInt(formData.unCode)
      )
    );
    
    if (existingCountry) {
      if (existingCountry.iso2.toLowerCase() === formData.iso2.toLowerCase()) {
        errors.iso2 = 'ISO2 code already exists';
      }
      if (existingCountry.iso3.toLowerCase() === formData.iso3.toLowerCase()) {
        errors.iso3 = 'ISO3 code already exists';
      }
      if (existingCountry.unCode === parseInt(formData.unCode)) {
        errors.unCode = 'UN code already exists';
      }
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Filter and search logic
  const filteredCountries = useMemo(() => {
    let filtered = countries;

    // Apply search across all visible text fields
    if (searchTerm) {
      const search = searchTerm.toLowerCase();
      filtered = filtered.filter(country =>
        country.nameEn.toLowerCase().includes(search) ||
        country.nameKa.toLowerCase().includes(search) ||
        country.iso2.toLowerCase().includes(search) ||
        country.iso3.toLowerCase().includes(search) ||
        country.unCode.toString().includes(search) ||
        country.country.toLowerCase().includes(search) ||
        (country.isActive ? 'active' : 'inactive').includes(search) ||
        country.ts.toLowerCase().includes(search)
      );
    }

    // Apply column filters
    Object.entries(columnFilters).forEach(([column, values]) => {
      if (values.length > 0) {
        filtered = filtered.filter(country => {
          const cellValue = String(country[column as ColumnKey]);
          return values.includes(cellValue);
        });
      }
    });

    return filtered;
  }, [countries, searchTerm, columnFilters]);

  // Sort logic
  const sortedCountries = useMemo(() => {
    if (!sortField) return filteredCountries;

    return [...filteredCountries].sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      
      if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredCountries, sortField, sortDirection]);

  const handleSort = (field: ColumnKey) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const getSortIcon = (field: ColumnKey) => {
    if (sortField !== field) return <ArrowUpDown className="h-3 w-3 opacity-50" />;
    return sortDirection === 'asc' 
      ? <ArrowUp className="h-3 w-3" />
      : <ArrowDown className="h-3 w-3" />;
  };

  const handleSave = () => {
    if (!validateForm()) return;
    
    if (editingCountry) {
      // Update existing
      setCountries(countries.map(country =>
        country.id === editingCountry.id
          ? { 
              ...country, 
              ...formData, 
              iso2: formData.iso2.toUpperCase(),
              iso3: formData.iso3.toUpperCase(),
              unCode: parseInt(formData.unCode) 
            }
          : country
      ));
      setIsEditDialogOpen(false);
      setEditingCountry(null);
    } else {
      // Add new
      const now = new Date().toISOString().split('T')[0]; // 2025-10-01 format
      const nowTimestamp = new Date().toISOString(); // 2025-10-01T12:00:00 format
      const newCountry = {
        id: Math.max(...countries.map(c => c.id)) + 1,
        createdAt: now,
        updatedAt: now,
        ts: nowTimestamp,
        countryUuid: `uuid-${Date.now()}`,
        ...formData,
        iso2: formData.iso2.toUpperCase(),
        iso3: formData.iso3.toUpperCase(),
        unCode: parseInt(formData.unCode)
      };
      setCountries([...countries, newCountry]);
      setIsAddDialogOpen(false);
    }
    
    resetForm();
  };

  const resetForm = () => {
    setFormData({
      nameEn: '',
      nameKa: '',
      iso2: '',
      iso3: '',
      unCode: '',
      country: '',
      isActive: true
    });
    setFormErrors({});
  };

  const startEdit = (country: Country) => {
    setEditingCountry(country);
    setFormData({
      nameEn: country.nameEn,
      nameKa: country.nameKa,
      iso2: country.iso2,
      iso3: country.iso3,
      unCode: country.unCode.toString(),
      country: country.country,
      isActive: country.isActive
    });
    setFormErrors({});
    setIsEditDialogOpen(true);
  };

  const cancelEdit = () => {
    setEditingCountry(null);
    setIsEditDialogOpen(false);
    resetForm();
  };

  const deleteCountry = (id: number) => {
    setCountries(countries.filter(c => c.id !== id));
  };

  // Get unique values for column filters
  const getUniqueValues = (column: ColumnKey) => {
    return [...new Set(countries.map(country => String(country[column])))].sort();
  };

  // Column filter component with Google Sheets-style search
  const ColumnFilter = ({ column }: { column: ColumnConfig }) => {
    const uniqueValues = getUniqueValues(column.key);
    const selectedValues = columnFilters[column.key] || [];
    const [filterSearchTerm, setFilterSearchTerm] = useState('');
    const [tempSelectedValues, setTempSelectedValues] = useState<string[]>(selectedValues);
    const [isOpen, setIsOpen] = useState(false);

    // Filter unique values based on search term
    const filteredUniqueValues = useMemo(() => {
      if (!filterSearchTerm) return uniqueValues;
      return uniqueValues.filter(value => 
        value.toLowerCase().includes(filterSearchTerm.toLowerCase())
      );
    }, [uniqueValues, filterSearchTerm]);

    // Reset temp values when opening
    const handleOpenChange = (open: boolean) => {
      setIsOpen(open);
      if (open) {
        setTempSelectedValues(selectedValues);
        setFilterSearchTerm('');
      }
    };

    // Apply filters
    const handleApply = () => {
      setColumnFilters({
        ...columnFilters,
        [column.key]: tempSelectedValues
      });
      setIsOpen(false);
    };

    // Cancel changes
    const handleCancel = () => {
      setTempSelectedValues(selectedValues);
      setIsOpen(false);
    };

    // Clear all selections
    const handleClearAll = () => {
      setTempSelectedValues([]);
    };

    // Select all visible values
    const handleSelectAll = () => {
      setTempSelectedValues(filteredUniqueValues);
    };

    // Sort values - numbers first, then text
    const sortedFilteredValues = useMemo(() => {
      return [...filteredUniqueValues].sort((a, b) => {
        const aIsNum = !isNaN(Number(a));
        const bIsNum = !isNaN(Number(b));
        
        if (aIsNum && bIsNum) {
          return Number(a) - Number(b);
        } else if (aIsNum && !bIsNum) {
          return -1;
        } else if (!aIsNum && bIsNum) {
          return 1;
        } else {
          return a.localeCompare(b);
        }
      });
    }, [filteredUniqueValues]);

    return (
      <Popover open={isOpen} onOpenChange={handleOpenChange}>
        <PopoverTrigger asChild>
          <Button 
            variant="ghost" 
            size="sm" 
            className={`h-6 px-1 ${selectedValues.length > 0 ? 'text-blue-600' : ''}`}
          >
            <Filter className="h-3 w-3" />
            {selectedValues.length > 0 && (
              <span className="ml-1 text-xs">{selectedValues.length}</span>
            )}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-72" align="start">
          <div className="space-y-3">
            {/* Header */}
            <div className="flex items-center justify-between border-b pb-2">
              <div className="font-medium text-sm">{column.label}</div>
              <div className="text-xs text-muted-foreground">
                Displaying {filteredUniqueValues.length}
              </div>
            </div>

            {/* Sort Options */}
            <div className="space-y-1">
              <button 
                className="w-full text-left text-sm py-1 px-2 hover:bg-muted rounded"
                onClick={() => {
                  const sorted = [...uniqueValues].sort();
                  setTempSelectedValues(tempSelectedValues.filter(v => sorted.includes(v)));
                }}
              >
                Sort A to Z
              </button>
              <button 
                className="w-full text-left text-sm py-1 px-2 hover:bg-muted rounded"
                onClick={() => {
                  const sorted = [...uniqueValues].sort().reverse();
                  setTempSelectedValues(tempSelectedValues.filter(v => sorted.includes(v)));
                }}
              >
                Sort Z to A
              </button>
            </div>

            {/* Filter by values section */}
            <div className="border-t pt-3">
              <div className="font-medium text-sm mb-2">Filter by values</div>
              
              {/* Select All / Clear controls */}
              <div className="flex items-center justify-between mb-2">
                <div className="flex gap-2">
                  <button
                    onClick={handleSelectAll}
                    className="text-xs text-blue-600 hover:underline"
                  >
                    Select all {filteredUniqueValues.length}
                  </button>
                  <span className="text-xs text-muted-foreground">·</span>
                  <button
                    onClick={handleClearAll}
                    className="text-xs text-blue-600 hover:underline"
                  >
                    Clear
                  </button>
                </div>
              </div>

              {/* Search input */}
              <div className="relative mb-3">
                <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-3 w-3 text-muted-foreground" />
                <Input
                  placeholder="Search values..."
                  value={filterSearchTerm}
                  onChange={(e) => setFilterSearchTerm(e.target.value)}
                  className="pl-7 h-8 text-sm"
                />
              </div>

              {/* Values list */}
              <div className="space-y-1 max-h-48 overflow-auto border rounded p-2">
                {sortedFilteredValues.length === 0 ? (
                  <div className="text-xs text-muted-foreground py-2 text-center">
                    No values found
                  </div>
                ) : (
                  sortedFilteredValues.map(value => (
                    <div key={value} className="flex items-center space-x-2 py-1">
                      <Checkbox
                        id={`${column.key}-${value}`}
                        checked={tempSelectedValues.includes(value)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setTempSelectedValues([...tempSelectedValues, value]);
                          } else {
                            setTempSelectedValues(tempSelectedValues.filter(v => v !== value));
                          }
                        }}
                      />
                      <Label htmlFor={`${column.key}-${value}`} className="text-sm flex-1 cursor-pointer">
                        {value}
                      </Label>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Action buttons */}
            <div className="flex justify-end space-x-2 pt-2 border-t">
              <Button variant="outline" size="sm" onClick={handleCancel}>
                Cancel
              </Button>
              <Button size="sm" onClick={handleApply} className="bg-green-600 hover:bg-green-700">
                OK
              </Button>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    );
  };

  // Column settings dialog
  const ColumnSettings = () => (
    <Dialog open={isSettingsOpen} onOpenChange={setIsSettingsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Settings className="h-4 w-4 mr-2" />
          Columns
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Column Settings</DialogTitle>
          <DialogDescription>
            Configure which columns to show and their visibility.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          {columns.map(column => (
            <div key={column.key} className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id={`col-${column.key}`}
                  checked={column.visible}
                  onCheckedChange={(checked) => {
                    setColumns(cols => cols.map(col =>
                      col.key === column.key
                        ? { ...col, visible: checked as boolean }
                        : col
                    ));
                  }}
                />
                <Label htmlFor={`col-${column.key}`} className="text-sm">
                  {column.label}
                </Label>
              </div>
              {column.visible ? (
                <Eye className="h-4 w-4 text-green-600" />
              ) : (
                <EyeOff className="h-4 w-4 text-gray-400" />
              )}
            </div>
          ))}
        </div>
        <div className="flex justify-end space-x-2">
          <Button
            variant="outline"
            onClick={() => {
              setColumns(defaultColumns);
              setIsSettingsOpen(false);
            }}
          >
            Reset
          </Button>
          <Button onClick={() => setIsSettingsOpen(false)}>
            Done
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );

  // Visible columns only
  const visibleColumns = columns.filter(col => col.visible);

  return (
    <div className="p-6 space-y-6 bg-background">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-medium text-foreground">Countries</h1>
          <p className="text-sm text-muted-foreground">
            Manage country data with comprehensive search and filtering
          </p>
        </div>
        <div className="flex items-center gap-2">
          <ColumnSettings />
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={resetForm}>
                <Plus className="h-4 w-4 mr-2" />
                Add Country
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Add New Country</DialogTitle>
                <DialogDescription>
                  Enter the details for the new country. All fields are required.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="add-nameEn" className="text-right">
                    Name EN
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="add-nameEn"
                      value={formData.nameEn}
                      onChange={(e) => {
                        setFormData({...formData, nameEn: e.target.value});
                        if (formErrors.nameEn) setFormErrors({...formErrors, nameEn: ''});
                      }}
                      className={formErrors.nameEn ? 'border-red-500' : ''}
                    />
                    {formErrors.nameEn && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.nameEn}</p>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="add-nameKa" className="text-right">
                    Name GE
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="add-nameKa"
                      value={formData.nameKa}
                      onChange={(e) => {
                        setFormData({...formData, nameKa: e.target.value});
                        if (formErrors.nameKa) setFormErrors({...formErrors, nameKa: ''});
                      }}
                      className={formErrors.nameKa ? 'border-red-500' : ''}
                    />
                    {formErrors.nameKa && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.nameKa}</p>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="add-iso2" className="text-right">
                    ISO2
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="add-iso2"
                      value={formData.iso2}
                      onChange={(e) => {
                        setFormData({...formData, iso2: e.target.value.toUpperCase()});
                        if (formErrors.iso2) setFormErrors({...formErrors, iso2: ''});
                      }}
                      className={formErrors.iso2 ? 'border-red-500' : ''}
                      maxLength={2}
                      placeholder="US"
                    />
                    {formErrors.iso2 && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.iso2}</p>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="add-iso3" className="text-right">
                    ISO3
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="add-iso3"
                      value={formData.iso3}
                      onChange={(e) => {
                        setFormData({...formData, iso3: e.target.value.toUpperCase()});
                        if (formErrors.iso3) setFormErrors({...formErrors, iso3: ''});
                      }}
                      className={formErrors.iso3 ? 'border-red-500' : ''}
                      maxLength={3}
                      placeholder="USA"
                    />
                    {formErrors.iso3 && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.iso3}</p>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="add-unCode" className="text-right">
                    UN Code
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="add-unCode"
                      type="number"
                      value={formData.unCode}
                      onChange={(e) => {
                        setFormData({...formData, unCode: e.target.value});
                        if (formErrors.unCode) setFormErrors({...formErrors, unCode: ''});
                      }}
                      className={formErrors.unCode ? 'border-red-500' : ''}
                      placeholder="268"
                    />
                    {formErrors.unCode && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.unCode}</p>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="add-country" className="text-right">
                    Country
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="add-country"
                      value={formData.country}
                      onChange={(e) => {
                        setFormData({...formData, country: e.target.value});
                        if (formErrors.country) setFormErrors({...formErrors, country: ''});
                      }}
                      className={formErrors.country ? 'border-red-500' : ''}
                      placeholder="ქვეყნის სახელი - CODE"
                    />
                    {formErrors.country && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.country}</p>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="add-isActive" className="text-right">
                    Status
                  </Label>
                  <div className="col-span-3">
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="add-isActive"
                        checked={formData.isActive}
                        onCheckedChange={(checked) => setFormData({...formData, isActive: checked})}
                      />
                      <span className="text-sm text-muted-foreground">
                        {formData.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSave}>Save Country</Button>
              </div>
            </DialogContent>
          </Dialog>

          {/* Edit Dialog */}
          <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Edit Country</DialogTitle>
                <DialogDescription>
                  Update the details for {editingCountry?.nameEn}. All fields are required.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-nameEn" className="text-right">
                    Name EN
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="edit-nameEn"
                      value={formData.nameEn}
                      onChange={(e) => {
                        setFormData({...formData, nameEn: e.target.value});
                        if (formErrors.nameEn) setFormErrors({...formErrors, nameEn: ''});
                      }}
                      className={formErrors.nameEn ? 'border-red-500' : ''}
                    />
                    {formErrors.nameEn && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.nameEn}</p>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-nameKa" className="text-right">
                    Name GE
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="edit-nameKa"
                      value={formData.nameKa}
                      onChange={(e) => {
                        setFormData({...formData, nameKa: e.target.value});
                        if (formErrors.nameKa) setFormErrors({...formErrors, nameKa: ''});
                      }}
                      className={formErrors.nameKa ? 'border-red-500' : ''}
                    />
                    {formErrors.nameKa && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.nameKa}</p>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-iso2" className="text-right">
                    ISO2
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="edit-iso2"
                      value={formData.iso2}
                      onChange={(e) => {
                        setFormData({...formData, iso2: e.target.value.toUpperCase()});
                        if (formErrors.iso2) setFormErrors({...formErrors, iso2: ''});
                      }}
                      className={formErrors.iso2 ? 'border-red-500' : ''}
                      maxLength={2}
                      placeholder="US"
                    />
                    {formErrors.iso2 && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.iso2}</p>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-iso3" className="text-right">
                    ISO3
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="edit-iso3"
                      value={formData.iso3}
                      onChange={(e) => {
                        setFormData({...formData, iso3: e.target.value.toUpperCase()});
                        if (formErrors.iso3) setFormErrors({...formErrors, iso3: ''});
                      }}
                      className={formErrors.iso3 ? 'border-red-500' : ''}
                      maxLength={3}
                      placeholder="USA"
                    />
                    {formErrors.iso3 && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.iso3}</p>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-unCode" className="text-right">
                    UN Code
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="edit-unCode"
                      type="number"
                      value={formData.unCode}
                      onChange={(e) => {
                        setFormData({...formData, unCode: e.target.value});
                        if (formErrors.unCode) setFormErrors({...formErrors, unCode: ''});
                      }}
                      className={formErrors.unCode ? 'border-red-500' : ''}
                      placeholder="268"
                    />
                    {formErrors.unCode && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.unCode}</p>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-country" className="text-right">
                    Country
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="edit-country"
                      value={formData.country}
                      onChange={(e) => {
                        setFormData({...formData, country: e.target.value});
                        if (formErrors.country) setFormErrors({...formErrors, country: ''});
                      }}
                      className={formErrors.country ? 'border-red-500' : ''}
                      placeholder="ქვეყნის სახელი - CODE"
                    />
                    {formErrors.country && (
                      <p className="text-xs text-red-500 mt-1">{formErrors.country}</p>
                    )}
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="edit-isActive" className="text-right">
                    Status
                  </Label>
                  <div className="col-span-3">
                    <div className="flex items-center space-x-2">
                      <Switch
                        id="edit-isActive"
                        checked={formData.isActive}
                        onCheckedChange={(checked) => setFormData({...formData, isActive: checked})}
                      />
                      <span className="text-sm text-muted-foreground">
                        {formData.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button variant="outline" onClick={cancelEdit}>
                  Cancel
                </Button>
                <Button onClick={handleSave}>Update Country</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Search and Stats */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center space-x-2 max-w-sm">
          <Search className="h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search across all fields..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1"
          />
        </div>
        <div className="text-sm text-muted-foreground">
          Showing {sortedCountries.length} of {countries.length} countries
        </div>
      </div>

      {/* Table */}
      <div className="border border-border rounded-lg bg-card shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/30 hover:bg-muted/30">
                {visibleColumns.map((column) => (
                  <TableHead
                    key={column.key}
                    className={`${getResponsiveClass(column.responsive)} relative group`}
                    style={{ width: column.width }}
                  >
                    <div className="flex items-center justify-between min-h-[40px]">
                      <div className="flex items-center space-x-2">
                        {column.sortable ? (
                          <button
                            onClick={() => handleSort(column.key)}
                            className="flex items-center space-x-1 font-medium hover:text-primary transition-colors"
                          >
                            <span>{column.label}</span>
                            {getSortIcon(column.key)}
                          </button>
                        ) : (
                          <span className="font-medium">{column.label}</span>
                        )}
                        {column.filterable && <ColumnFilter column={column} />}
                      </div>
                      
                      {/* Resize handle */}
                      <div
                        className="absolute right-0 top-0 bottom-0 w-1 cursor-col-resize bg-transparent hover:bg-border group-hover:bg-border transition-colors"
                        onMouseDown={(e) => {
                          e.preventDefault();
                          setIsResizing({
                            column: column.key,
                            startX: e.clientX,
                            startWidth: column.width
                          });
                        }}
                      />
                    </div>
                  </TableHead>
                ))}
                <TableHead className="w-24">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedCountries.map((country) => (
                <TableRow key={country.id} className="hover:bg-muted/50 transition-colors">
                  {visibleColumns.map((column) => (
                    <TableCell
                      key={column.key}
                      className={getResponsiveClass(column.responsive)}
                      style={{ width: column.width }}
                    >
                      <div className="py-1">
                        {column.key === 'isActive' ? (
                          <Badge variant={country.isActive ? "success" : "error"} className="text-xs">
                            {country.isActive ? 'Active' : 'Inactive'}
                          </Badge>
                        ) : column.key === 'id' ? (
                          <span className="text-sm">{country.id}</span>
                        ) : column.key === 'createdAt' ? (
                          <span className="text-sm">{country.createdAt}</span>
                        ) : column.key === 'updatedAt' ? (
                          <span className="text-sm">{country.updatedAt}</span>
                        ) : column.key === 'ts' ? (
                          <span className="text-sm">{country.ts}</span>
                        ) : column.key === 'countryUuid' ? (
                          <span className="text-sm">{country.countryUuid}</span>
                        ) : column.key === 'nameEn' ? (
                          <span className="text-sm">{country.nameEn}</span>
                        ) : column.key === 'nameKa' ? (
                          <span className="text-sm">{country.nameKa}</span>
                        ) : column.key === 'iso2' ? (
                          <span className="text-sm">{country.iso2}</span>
                        ) : column.key === 'iso3' ? (
                          <span className="text-sm">{country.iso3}</span>
                        ) : column.key === 'unCode' ? (
                          <span className="text-sm">{country.unCode}</span>
                        ) : column.key === 'country' ? (
                          <span className="text-sm">{country.country}</span>
                        ) : (
                          <span className="text-sm">-</span>
                        )}
                      </div>
                    </TableCell>
                  ))}
                  <TableCell className="w-24">
                    <div className="flex items-center space-x-1">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => startEdit(country)}
                        className="h-7 w-7 p-0"
                        title="Edit country"
                      >
                        <Edit2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Empty state */}
      {sortedCountries.length === 0 && (
        <div className="text-center py-12">
          <div className="text-muted-foreground">
            {searchTerm || Object.values(columnFilters).some(f => f.length > 0) ? (
              <>
                <p className="text-lg font-medium mb-2">No countries found</p>
                <p className="text-sm">Try adjusting your search or filters</p>
              </>
            ) : (
              <>
                <p className="text-lg font-medium mb-2">No countries added yet</p>
                <p className="text-sm">Get started by adding your first country</p>
              </>
            )}
          </div>
        </div>
      )}

      {/* Active filters indicator */}
      {Object.values(columnFilters).some(filters => filters.length > 0) && (
        <div className="flex items-center space-x-2 text-sm">
          <span className="text-muted-foreground">Active filters:</span>
          {Object.entries(columnFilters).map(([column, values]) =>
            values.length > 0 ? (
              <Badge key={column} variant="secondary" className="text-xs">
                {columns.find(c => c.key === column)?.label}: {values.length}
              </Badge>
            ) : null
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setColumnFilters({})}
            className="h-6 px-2 text-xs"
          >
            Clear all
          </Button>
        </div>
      )}
    </div>
  );
}